# Running the flask app
## setting up

Run envivonment (environment used is pipenv)
Run shell - (pipenv shell)
Install all dependancies -(pipenv install)
point the run to run.py (export FLASK_APP=run.py)
Run app (flask run)
Incase of errors run the run.py file install all dependancies in requirements.txt ( pip install (the dependancy name))